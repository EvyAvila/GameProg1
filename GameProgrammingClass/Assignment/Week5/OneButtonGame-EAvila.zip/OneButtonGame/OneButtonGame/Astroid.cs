﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Sprite;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneButtonGame
{
    class Astroid : DrawableSprite
    {
        protected static short astroidCount;

        Texture2D astroidTexture;
        public Astroid(Game game) : base(game)
        {
            astroidCount++;
        }

        protected override void LoadContent()
        {
            this.astroidTexture = this.Game.Content.Load<Texture2D>("rocks");
            this.SpriteTexture = astroidTexture;

            this.Location = new Vector2(100 + (100 * astroidCount), 100);
            this.Speed = 0;
            this.Origin = new Vector2(this.spriteTexture.Width / 2, this.spriteTexture.Height / 2);
            this.Scale = 1;
            astroidCount++;

            base.LoadContent();

        }

        public override void Update(GameTime gameTime)
        {
            Moving();
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }

        public void Moving()
        {
            if(this.Location.X < 900)
            {
                this.Location.X += 5;
                
            }

            if (this.Location.X == 900)
            {
                this.Location.X = -50;
            }
        }

        public void StopRock()
        {
            this.Location.X += -5;
        }
    }
}
