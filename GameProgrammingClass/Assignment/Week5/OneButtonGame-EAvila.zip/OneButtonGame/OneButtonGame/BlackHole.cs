﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Sprite;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneButtonGame
{
    class BlackHole : DrawableSprite
    {
        protected static short blackHoleCount;

        Texture2D theBlackHoleTexture;

        public BlackHole(Game game) : base(game)
        {
            blackHoleCount++;
        }

        protected override void LoadContent()
        {
            this.theBlackHoleTexture = this.Game.Content.Load<Texture2D>("BlackHolesSideWays");
            this.SpriteTexture = theBlackHoleTexture;

            this.Location = new Vector2(100 + (100 * blackHoleCount), 100);
            this.Speed = 0;

            base.LoadContent();

            this.Origin = new Vector2(this.spriteTexture.Width / 2, this.spriteTexture.Height / 2);
            this.Scale = 1;
            blackHoleCount++;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }


    }
}
