﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary.Util;
using System.Collections.Generic;

namespace OneButtonGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        //Sevices from MonogameLibrary.Util
        //InputHandler input;     //Input Handler
        GameConsole console;    //Game Console for logging
       

        Ship ship;
        BlackHole blackHole;
        
        Astroid astroid, astroid2, astroid3, astroid4, astroid5;

        SpriteFont theFont;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            _graphics.PreferredBackBufferWidth = 500;
           _graphics.PreferredBackBufferHeight = 1300;

            #region AddingComponents
            //create instance of services
            //input = new InputHandler(this);
            console = new GameConsole(this);
            

            //Add components to game
            //this.Components.Add(input);
            this.Components.Add(console);
           
           
            blackHole = new BlackHole(this);
            blackHole.ShowMarkers = false;
            this.Components.Add(blackHole);

            astroid = new Astroid(this);
            astroid.ShowMarkers = false;
            this.Components.Add(astroid);

            astroid2 = new Astroid(this);
            astroid2.ShowMarkers = false;
            this.Components.Add(astroid2);

            astroid3 = new Astroid(this);
            astroid3.ShowMarkers = false;
            this.Components.Add(astroid3);

            astroid4 = new Astroid(this);
            astroid4.ShowMarkers = false;
            this.Components.Add(astroid4);

            astroid5 = new Astroid(this);
            astroid5.ShowMarkers = false;
            this.Components.Add(astroid5);

            ship = new Ship(this, new List<Astroid>() { astroid, astroid2, astroid3, astroid4, astroid5 }, blackHole);
            ship.ShowMarkers = false;
            this.Components.Add(ship);
            #endregion
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            theFont = Content.Load<SpriteFont>("Font");

            #region SettingUpSpecificLocation
            blackHole.Location = new Vector2(250, 1275);

            astroid.Location = new Vector2(250, 300);
            astroid2.Location = new Vector2(350, 500);
            astroid3.Location = new Vector2(50, 700);
            astroid4.Location = new Vector2(400, 900);
            astroid5.Location = new Vector2(150, 1100);
            #endregion
           
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DarkSlateBlue);

            #region TheTextDisplaying
            _spriteBatch.Begin();
            
            _spriteBatch.DrawString(theFont, "Get to the bottom of the screen. Avoid astroids by pressing R", new Vector2(20,25), Color.White);

            //Displays the text depending on the interaction
            if (ship.Intersects(blackHole))
            {
                _spriteBatch.DrawString(theFont, "You escaped! Press R to restart!", new Vector2(150, 8), Color.White);
            }
            

            if (ship.Intersects(astroid) || ship.Intersects(astroid2) || ship.Intersects(astroid3) || ship.Intersects(astroid4) || ship.Intersects(astroid5))
            {
                _spriteBatch.DrawString(theFont, "You got hit! Press R to restart!", new Vector2(150, 8), Color.White);
          
            }

            _spriteBatch.End();
            #endregion

            base.Draw(gameTime);
        }

     
    }
}
